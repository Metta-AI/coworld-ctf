"""Execute the frozen six-cell campaign; never replace or overwrite a run."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import statistics
from run_case import run

ROOT = Path('/workspace/ctf')
HERE = ROOT/'docs/research/nav-512-2026-09-11/qualification'
PREFIXES = ('SHELL_PLAN_BUDGET ', 'SHELL_NAV ', 'SHELL_INSTALL ', 'SHELL_MOVEMENT ')

def inspect(directory, case):
    if (directory/'failure.json').exists():
        raise RuntimeError(f'failed run: {directory}')
    exit_info = json.loads((directory/'exit.json').read_text())
    log = (directory/'server.log').read_text()
    frames = [(int(t),int(ns)) for t,ns in re.findall(r'^BUDGET_FRAME tick=(\d+) ns=(\d+)$',log,re.M)]
    if exit_info['code'] != 0 or len(frames) != 1200 or {t for t,_ in frames} != set(range(1,1201)):
        raise RuntimeError(f'incomplete frame coverage: {directory}')
    guests = {int(s) for s in re.findall(r'^SHELL_PLAY_LOG tick=\d+ seat=(\d+) entry='+re.escape(case['play'])+r' phase=init',log,re.M)}
    census = {int(s) for s in re.findall(r'^SHELL_MOVEMENT tick=\d+ seats=(\d+)',log,re.M)}
    if guests != set(range(case['seats'])) or census != {case['seats']} or 'kind=play_fault' in log:
        raise RuntimeError(f'guest, seat or fault coverage failed: {directory}')
    semantic = '\n'.join(l for l in log.splitlines() if l.startswith(PREFIXES))
    values = sorted(ns for _,ns in frames)
    shell = re.findall(r'^BUDGET_SHELL tick=\d+ ns=\d+ pending=(\d+) no_path=(\d+) stale=(\d+)$',log,re.M)
    if len(shell)!=1200: raise RuntimeError(f'missing shell counters: {directory}')
    result = dict(total_ns=sum(values),p50_ns=values[599],p95_ns=values[1139],max_ns=values[-1],
                  deadline_misses=sum(v*24>1_000_000_000 for v in values),
                  semantic_sha256=hashlib.sha256(semantic.encode()).hexdigest(),
                  pending_seat_ticks=sum(int(x[0]) for x in shell),
                  no_path_seat_ticks=sum(int(x[1]) for x in shell),
                  stale_seat_ticks=sum(int(x[2]) for x in shell),exit=exit_info)
    (directory/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

parser=argparse.ArgumentParser()
parser.add_argument('phase',choices=['correctness','performance'])
args=parser.parse_args()
results=Path('/qualification-results')
manifest=json.loads((HERE/'proposed-configs/manifest.json').read_text())
assets=json.loads((results/'assets.json').read_text())
for path,digest in assets.items():
    if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest: raise RuntimeError(f'asset changed: {path}')
for case in manifest:
    p=HERE/'proposed-configs'/case['config']
    if hashlib.sha256(p.read_bytes()).hexdigest()!=case['sha256']: raise RuntimeError(f'config changed: {p}')

def execute(case, variant, budget, repeat):
    directory=results/args.phase/case['name']/f'{variant}-b{budget}-r{repeat}'
    if directory.exists(): raise RuntimeError(f'refusing to overwrite: {directory}')
    server=Path('/original/server-256') if variant=='parent' else Path(f'/candidate/server-{budget}')
    print(f'START {args.phase} {case["name"]} {variant} {budget} repeat={repeat}',flush=True)
    try:
        run(HERE/'proposed-configs'/case['config'],server,Path('/original/presence'),directory,{5})
        return inspect(directory,case)
    except Exception as error:
        if directory.exists(): (directory/'failure.json').write_text(json.dumps(dict(type=type(error).__name__,error=str(error)))+'\n')
        raise

rows=[]
if args.phase=='correctness':
    for case in manifest:
        parent=execute(case,'parent',256,1)
        candidate=execute(case,'candidate',256,1)
        if parent['semantic_sha256']!=candidate['semantic_sha256']:
            raise RuntimeError(f'same-budget semantic mismatch: {case["name"]}')
        rows.append(dict(case=case['name'],parent=parent,candidate=candidate))
    (results/'correctness-passed.json').write_text(json.dumps(rows,indent=2)+'\n')
else:
    passed=json.loads((results/'correctness-passed.json').read_text())
    if [r['case'] for r in passed]!=[c['name'] for c in manifest]:raise RuntimeError('incomplete correctness campaign')
    for repeat in range(1,4):
        for index,case in enumerate(manifest):
            order=[('parent',256),('candidate',512)]
            if (index+repeat-1)%2:order.reverse()
            for variant,budget in order:
                metrics=execute(case,variant,budget,repeat)
                rows.append(dict(case=case['name'],variant=variant,budget=budget,repeat=repeat,**metrics))
                (results/'performance-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
    decisions=[]
    for case in manifest:
        pairs=[]
        for repeat in range(1,4):
            parent=next(r for r in rows if r['case']==case['name'] and r['variant']=='parent' and r['repeat']==repeat)
            candidate=next(r for r in rows if r['case']==case['name'] and r['variant']=='candidate' and r['repeat']==repeat)
            pairs.append({key:candidate[key]/parent[key] for key in ('total_ns','p50_ns','p95_ns','max_ns')})
        medians={key:statistics.median(p[key] for p in pairs) for key in pairs[0]}
        worst={v:max(r['deadline_misses'] for r in rows if r['case']==case['name'] and r['variant']==v) for v in ['parent','candidate']}
        exact=all(len({r['semantic_sha256'] for r in rows if r['case']==case['name'] and r['variant']==v})==1 for v in ['parent','candidate'])
        decisions.append(dict(case=case['name'],ratios=pairs,median_ratios=medians,worst_misses=worst,
                              repeat_exact=exact,passed=exact and all(v<=1 for v in medians.values()) and worst['candidate']<=worst['parent']))
    (results/'performance-verdict.json').write_text(json.dumps(dict(cases=decisions,passed=all(c['passed'] for c in decisions)),indent=2)+'\n')
